import { useEffect, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
//import AdminService from "../../Services/AdminService"
import VendorServices from '../../Services/VendorServices';
import ReactConfirmAlert, { confirmAlert } from 'react-confirm-alert';
import 'react-confirm-alert/src/react-confirm-alert.css';
import DishService from '../../Services/DishService';
import {FaSignOutAlt} from 'react-icons/fa';


const AdminsList = () => {
const Navigate=useNavigate();
const [dishes,setDishes]=useState([]);
  const [vendors, setVendors] = useState([]);

  const init = () => {
    VendorServices.getAll()
      .then(response => {
        console.log('Printing vendors data', response.data);
        setVendors(response.data);



        DishService.getAll()
                .then(response => {
                  console.log('Printing Dishes data', response.data);
                setDishes(response.data);
                
                })
                .catch(error => {
                  console.log('Something went wrong', error);
                }) 
      })
      .catch(error => {
        console.log('Something went wrong', error);
      }) 
  }

  useEffect(() => {
    init();
  }, []);
 
  const handleDelete = (vendor) => {

    const vid=vendor.vid;
    const name=vendor.name;
    console.log('Printing id',vid);
    const info=dishes.filter((nm)=>
    nm.vname.includes(name))
    console.log("ingo is",info);

   
    confirmAlert({
      title: 'Confirm to delete',
      message: 'Are you sure to do this.',
      buttons: [
        {
          label: 'Yes',
          onClick: () => {
            VendorServices.remove(vid)
          .then(response => {
            console.log('vendor deleted successfully', response.data);
           
            info.map((ditem)=>{
              const dishid=ditem.did;
              console.log(dishid);
              DishService.remove(dishid);
              init();
            })

          })
          .catch(error => {
            console.log('Something went wrong', error);
          })
          
        }
        },
        {
          label: 'No',
          onClick: () => alert('Not deleted')
        }
      ]
    });
    
  }

  const Logoutadm = () => {
  
    confirmAlert({
      title: 'Confirm to LogOut',
      message: 'Are you sure to do this.',
      buttons: [
        {
          label: 'Yes',
          onClick: () => {localStorage.removeItem("adminid")
                          Navigate("/")
        }
        },
        {
          label: 'No',
          onClick: () =>console.log("Not logged out")
        }
      ]
    });  
  }

  return (
    <div className="container">
      <h3>List of Vendors</h3>
      <hr/>
      <div>
      <button className="btn btn-primary mb-2" onClick={Logoutadm}>
      <FaSignOutAlt color="white" fontSize="25px"/>Logout</button>
        
        <table className="table table-bordered table-striped">
          <thead className="thead-dark">
            <tr>
              <th>Name</th>
              <th>Mobile</th>
              <th>City</th>
              <th>Username</th>
             
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
          {
            vendors.map(vendor => (
              <tr key={vendor.vid}>
                
                <td>{vendor.name}</td>
                <td>{vendor.mobile}</td>
                <td>{vendor.city}</td>
                <td>{vendor.vuname}</td>
                


                <td>
                  <Link className="btn btn-info" to={`/vendor/edit/${vendor.vid}`}>Update</Link>
                  
                  <button className="btn btn-danger ml-2" onClick={() => {
                    handleDelete(vendor);
                  }}>Delete</button>
                </td>
              </tr>
            ))
          }
          </tbody>
        </table>
        
      </div>
    </div>
  );
}

export default AdminsList;