import { useState } from "react";
import { Link, unstable_HistoryRouter, useNavigate, useParams } from "react-router-dom";
import { useEffect } from "react";


import VendorServices from '../../Services/VendorServices';
const AddVendors = () => {
    const[name, setName] = useState('');
    const[mobile, setMobile] = useState('');
    const[city, setCity] = useState('');
    const[vuname, setVuname] = useState('');
    const[pass, setPass] = useState('');
    const[secQue, setQue] = useState('');
    const[secAns, setAns] = useState('');

    const history = useNavigate();
    const {vid} = useParams();

    const saveVendor = (e) => {
        e.preventDefault();
        
        const vendor = {name,mobile, city,vuname,pass,secQue,secAns,vid};
        if (vid) {
            //update
            VendorServices.update(vendor)
                .then(response => {
                    console.log('Vendors data updated successfully', response.data);
        history('/admindash');
                })
                .catch(error => {
                    console.log('Something went wrong', error);
                }) 
        } else {
            //create
            VendorServices.create(vendor)
            .then(response => {
                console.log("vendor added successfully", response.data);
                history("/admindash");
            })
            .catch(error => {
                console.log('something went wroing', error);
            })
        }
    }

    useEffect(() => {
        if (vid) {
            VendorServices.get(vid)
                .then(vendor => {
                    setName(vendor.data.name);
                    setMobile(vendor.data.mobile);
                    setCity(vendor.data.city);
                    setVuname(vendor.data.vuname);
                    setPass(vendor.data.pass);
                    setQue(vendor.data.secQue)
                    setAns(vendor.data.secAns);
                })
                .catch(error => {
                    console.log('Something went wrong', error);
                })
        }
    }, [])
    return(
        <div className="container">
            <h3>Update Vendor Details</h3>
            <hr/>
            <form>
            <div className="form-group">
                    <input 
                        type="text" 
                        className="form-control col-4"
                        id="name"
                        value={name}
                        onChange={(e) => setName(e.target.value)}
                        
                        placeholder="Enter Your  Bussiness name"/>

                </div>
                <br></br>
                <div className="form-group">
                    <input 
                        type="text" 
                        className="form-control col-4"
                        id="mobile"
                        value={mobile}
                        onChange={(e) => setMobile(e.target.value)}
                        
                        placeholder="Enter Mobile"
                    />

                </div>
                <br></br>
                <div className="form-group">
                    <input 
                        type="text" 
                        className="form-control col-4"
                        id="address"
                        value={city}
                        onChange={(e) => setCity(e.target.value)}
                        
                        placeholder="Enter Address"
                    />
                </div>
                <br></br>

                <div className="form-group">
                    <input 
                        type="text" 
                        className="form-control col-4"
                        id="uname"
                        value={vuname}
                        onChange={(e) => setVuname(e.target.value)}

                        placeholder="Create a username"
                    />
                </div> <br/><br/>

                <div >
                  {/*  <Link  onClick={(e) => saveVendor(e)} className="btn btn-primary" to='/loginadmin/login'>Save</Link>*/}
                 <button onClick={(e) => saveVendor(e)} className="btn btn-primary">Save</button>
                </div>
            </form>
            <hr/>
            <Link to="/admindash">Back to List</Link>
        </div>
    )
}

export default AddVendors;