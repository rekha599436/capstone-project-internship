import NavPre from "./prelognav";
import Routers from "./prerouters";
import '../App.css'


function MainPage() {
  return (
 <>
    <Routers/>
    {/*<center>
      
      <img src="https://hips.hearstapps.com/hmg-prod.s3.amazonaws.com/images/sant-ambroeus-brookfield-dining-room-011-1616612389.jpg" className='card-img-top' width='100px' height='400px'/>
      <p>
        Hi! everyone this is our Foody. We have a different vendors with their beautiful and tasty dishes.
      </p>
      <table className="table table-bordered table-striped">
      <thead className="thead-dark">
        <tr>
          <th>Services</th>
          <th></th>
        </tr>
        </thead>
        <tr>
          <td><img src="https://jedloapp.in/wp-content/uploads/2020/08/about-jedlo.jpg"  className='card-img-top' width='200px' height='150px'></img></td>
          <td>Get your favourite food at anytime</td>
        </tr>
        <tr>
          <td><img src="https://media.istockphoto.com/vectors/safe-food-delivery-at-home-during-coronavirus-covid19-epidemic-vector-id1218608037?k=20&m=1218608037&s=170667a&w=0&h=QMkmsbYhb7ZMB14SRrmrzsNcu1vYMdKhCo2qO39D36c="  className='card-img-top' width='200px' height='150px'></img></td>
          <td>Deliver Your food safely</td>
        </tr>
        <tr>
          <td><img src="https://manofmany.com/wp-content/uploads/2019/02/menulog-food-delivery-app-4.jpg"  className='card-img-top' width='200px' height='150px'></img></td>
          <td>We are providing this "Foody" with lot many dishes. So no more waiting just go and order your favourite dish</td>
        </tr>
      </table>
    </center> */ }
 </>
  );
}

export default MainPage;
