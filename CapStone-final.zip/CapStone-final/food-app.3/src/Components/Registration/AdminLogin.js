
import { useState ,useEffect} from "react";
import { useNavigate } from "react-router-dom";
import AdminService from "../../Services/AdminService";


function LoginAdmin() {
const Navigate=useNavigate();
   const[addata,setAddata]=useState('')
    const[auname, setaUname] = useState('');
    const[pass, setPass] = useState('');
    const init = () => {
        AdminService.getAll()
        .then(response => {
        console.log('Printing Admin data', response.data);
        setAddata(response.data);
        })
        .catch(error => {
        console.log('Something went wrong', error);
        })
        }
        
        
        
        useEffect(() => {
        init();
        }, []);
    
    const LoginHandle = (e) => {
        e.preventDefault();
        addata.map((ud)=>{
            if (ud.admid==auname && ud.pass==pass) {
                Navigate("/admindash");
                localStorage.setItem("adminid",ud.admid)
               
            }
        })  
      }


  return (
 <div>
    
    <br></br>
    <div className="container">
<h2>Admin Login</h2>
<br></br>

    <form>
                <div className="form-group">
                    <input 
                        type="text" 
                        className="form-control col-4"
                        id="uname"
                        value={auname}
                        onChange={(e) => setaUname(e.target.value)}

                        placeholder="Enter Username"
                    />

                </div>

                <br></br>

                <div className="form-group">
                    <input 
                        type="password" 
                        className="form-control col-3"
                        id="pass"

                        value={pass}
                        onChange={(e) => setPass(e.target.value)}
                        placeholder="Enter a Password"

                    />

                </div><br/><br/>


                <div >
                    <button  className="btn btn-primary" onClick={LoginHandle} >Login Now</button>
                </div>
            </form>
            <h5> </h5>
    </div>
 </div>
  );
}

export default LoginAdmin;
