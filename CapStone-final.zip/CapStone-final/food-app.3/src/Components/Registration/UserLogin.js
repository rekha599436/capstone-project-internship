
import { render } from "@testing-library/react";
import { useState,useEffect} from "react";
import { Link, useNavigate, useParams } from "react-router-dom";

import UserService from "../../Services/UserService";

function LoginUser() {
const Navigate=useNavigate();
   
const[usdata, setUsdata] = useState('');
    const[uname, setUname] = useState('');
    const[pass, setPass] = useState('');

    const init = () => {
        UserService.getAll()
        .then(response => {
        console.log('Printing Uses data', response.data);
        setUsdata(response.data);
        })
        .catch(error => {
        console.log('Something went wrong', error);
        })
        }
        
        
        
        useEffect(() => {
        init();
        }, []);
    
    const LoginHandle = (e) => {
        e.preventDefault();
        usdata.map((ud)=>{
            if (ud.uname==uname && ud.pass==pass) {
                Navigate("/userdash");
                localStorage.setItem("username",ud.uname)
                localStorage.setItem("ufname",ud.name)
                localStorage.setItem("uadr",ud.address)
                localStorage.setItem("umob",ud.mobile)
            }
        })
      
    }
 

  return (
      
 <div>
    
    <br></br>
    <div className="container">
<h2>User Login</h2>
<br></br>

    <form>
                <div className="form-group">
                    <input 
                        type="text" 
                        className="form-control col-4"
                        id="uname"
                        value={uname}
                        onChange={(e) => setUname(e.target.value)}

                        placeholder="Enter Username"
                    />

                </div>

                <br></br>

                <div className="form-group">
                    <input 
                        type="password" 
                        className="form-control col-3"
                        id="pass"

                        value={pass}
                        onChange={(e) => setPass(e.target.value)}
                        placeholder="Enter a Password"

                    />

                </div><br/><br/>


                <div >
                    <button  className="btn btn-primary" onClick={LoginHandle} >Login Now</button>
                </div>
            </form>
            
            <Link to="/registeruser">Not yet registered?</Link><br/>
            <Link to="/userforget">Forget Password</Link>
    </div>
 </div>
  );
}

export default LoginUser;
