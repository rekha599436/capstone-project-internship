
import { useState } from "react";
import { Link, useHistory, useParams } from "react-router-dom";

import UserService from "../../Services/UserService";

function RegisterUser() {

    const[name, setName] = useState('');
    const[mobile, setmobile] = useState('');
    const[address, setAddress] = useState('');
    const[uname, setUname] = useState('');
    const[pass, setPass] = useState('');
    const[secQue, setQue] = useState('Select A Question');
    const[secAns, setAns] = useState('');


   

    const saveUser = (e) => {
        e.preventDefault();
        
        const User = {name, mobile, address,uname,pass,secQue,secAns};
       UserService.create(User)
        .then(response => {
            console.log("User added successfully", response.data);
            alert("Registration Successfull!!!");
            setName('')
            setmobile('')
            setAddress('')
            setUname('')
            setPass('')
            setQue('')
            setAns('')
        })
        }
  

  return (
 <div>
    
    <br></br>
    <div className="container">
<h2>Register Me!</h2>
<br></br>

    <form>
                <div className="form-group">
                    <input 
                        type="text" 
                        className="form-control col-4"
                        id="name"
                        value={name}
                        onChange={(e) => setName(e.target.value)}
                        
                        placeholder="Enter Your name"/>

                </div>
                <br></br>
                <div className="form-group">
                    <input 
                        type="text" 
                        className="form-control col-4"
                        id="mobile"
                        value={mobile}
                        onChange={(e) => setmobile(e.target.value)}
                        
                        placeholder="Enter Mobile"
                    />

                </div>
                <br></br>
                <div className="form-group">
                    <input 
                        type="text" 
                        className="form-control col-4"
                        id="address"
                        value={address}
                        onChange={(e) => setAddress(e.target.value)}
                        
                        placeholder="Enter Address"
                    />
                </div>
                <br></br>

                <div className="form-group">
                    <input 
                        type="text" 
                        className="form-control col-4"
                        id="uname"
                        value={uname}
                        onChange={(e) => setUname(e.target.value)}

                        placeholder="Create a username"
                    />

                </div>

                <br></br>

                <div className="form-group">
                    <input 
                        type="text" 
                        className="form-control col-4"
                        id="pass"

                        value={pass}
                        onChange={(e) => setPass(e.target.value)}
                        placeholder="Create a Password"

                    />

                </div>

                <br></br>


                <div className="form-group">
                
                <label>Security Question :- </label>
               
               <select name="ques" id="ques" 
               value={secQue}
               onChange={(e) => setQue(e.target.value)}
               > 
               <option value="Pet Name">Your Pet Name</option>
              <option value="School Name">Your School Name</option>
              <option value="Best Singer">Who is best Singer</option>
              <option value="Best meal">Best food</option>

            </select>


                </div>
                <br></br>
                <div className="form-group">
                    <input 
                        type="text" 
                        className="form-control col-4"
                        id="Ans"
                        value={secAns}
                        onChange={(e) => setAns(e.target.value)}
                        
                        placeholder="Enter the Answer "
                    />

                </div><br/>


                <div >
                    <button  className="btn btn-primary" onClick={saveUser}>Register</button>
                </div>
            </form>
            <h5> </h5>
            <Link to="/loginuser">Go for login</Link>
    </div>
 </div>
  );
}

export default RegisterUser;
