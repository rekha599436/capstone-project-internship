
import { useState,useEffect } from "react";
import { Link, useNavigate, useParams } from "react-router-dom";

//import UserService from "../../Services/UserService";

import VendorServices from "../../Services/VendorServices";

    

function LoginVendor() {

   const Navigate=useNavigate();
    const[uname, setVUname] = useState('');
    const[pass, setPass] = useState('');
    const [logind, setLogind] = useState([]);



    const init = () => {
    VendorServices.getAll()
    .then(response => {
    console.log('Printing Vendor data', response.data);
    setLogind(response.data);
    })
    .catch(error => {
    console.log('Something went wrong', error);
    })
    }
    
    
    
    useEffect(() => {
    init();
    }, []);
   
const LoginHandle = (e) => {
    e.preventDefault();
    logind.map((vd)=>{
        if (vd.vuname==uname && vd.pass==pass) {
            Navigate("/vendordash");
            localStorage.setItem("vendorname",vd.name)
        }
    })
    
  
}
   



  return (
 <div>
   
    <br></br>
    <div className="container">
<h2>Vendor Login</h2>
<br></br>

    <form>
                <div className="form-group">
                    <input 
                        type="text" 
                        className="form-control col-4"
                        id="uname"
                        value={uname}
                        onChange={(e) => setVUname(e.target.value)}

                        placeholder="Enter Username"
                    />

                </div>

                <br></br>

                <div className="form-group">
                    <input 
                        type="password" 
                        className="form-control col-3"
                        id="pass"

                        value={pass}
                        onChange={(e) => setPass(e.target.value)}
                        placeholder="Enter a Password"

                    />

                </div><br/>

                <div >
                    <button  className="btn btn-primary" onClick={LoginHandle}>Login Now</button>
                </div>
            </form>
            <h5> </h5>
            <Link to="/registervendor">Not yet registered?</Link><br/>
            <Link to="/vendorforget">Forget Password</Link>
    </div>
 </div>
  );
}

export default LoginVendor;
