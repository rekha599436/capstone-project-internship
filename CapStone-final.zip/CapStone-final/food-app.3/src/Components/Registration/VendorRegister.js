
import { useState } from "react";
import { Link } from "react-router-dom";
import VendorServices from "../../Services/VendorServices"

    

function RegisterVendor() {

    const[name, setName] = useState('');
    const[mobile, setmobile] = useState('');
    const[city, setCity] = useState('');
    const[vuname, setVUname] = useState('');
    const[pass, setPass] = useState('');
    const[secQue, setQue] = useState('Select A Question');
    const[secAns, setAns] = useState('');


   

    const saveVendor = (e) => {
        e.preventDefault();
        
        const Vendor = {name, mobile, city,vuname,pass,secQue,secAns};
       VendorServices.create(Vendor)
        .then(response => {
            console.log("Vendor added successfully", response.data);
            alert("Thank You for Registerin with us!!Our Executive will Call and visit your location within 48 hours For confirmation purpose. ");
        setName('')
        setmobile('')
        setCity('')
        setVUname('')
        setPass('')
        setQue('')
        setAns('')
        })
      
    }
           
  
  return (
 <div>
  
    <br></br>
    <div className="container">
<h2>First Step to be part of our Family!</h2>
<br></br>

    <form>
                <div className="form-group">
                    <input 
                        type="text" 
                        className="form-control col-4"
                        id="name"
                        value={name}
                        onChange={(e) => setName(e.target.value)}
                        
                        placeholder="Enter Your  Bussiness name"/>

                </div>
                <br></br>
                <div className="form-group">
                    <input 
                        type="text" 
                        className="form-control col-4"
                        id="mobile"
                        value={mobile}
                        onChange={(e) => setmobile(e.target.value)}
                        
                        placeholder="Enter Mobile"
                    />

                </div>
                <br></br>
                <div className="form-group">
                    <input 
                        type="text" 
                        className="form-control col-4"
                        id="address"
                        value={city}
                        onChange={(e) => setCity(e.target.value)}
                        
                        placeholder="Enter Address"
                    />
                </div>
                <br></br>

                <div className="form-group">
                    <input 
                        type="text" 
                        className="form-control col-4"
                        id="uname"
                        value={vuname}
                        onChange={(e) => setVUname(e.target.value)}

                        placeholder="Create a username"
                    />

                </div>

                <br></br>

                <div className="form-group">
                    <input 
                        type="text" 
                        className="form-control col-4"
                        id="pass"

                        value={pass}
                        onChange={(e) => setPass(e.target.value)}
                        placeholder="Create a Password"

                    />

                </div>

                <br></br>


                <div className="form-group">
                
                <label>Security Question :- </label>
               
               <select name="ques" id="ques" 
               value={secQue}
               onChange={(e) => setQue(e.target.value)}
               > 
               <option value="Pet Name">Your Pet Name</option>
              <option value="School Name">Your School Name</option>
              <option value="Best Singer">Who is best Singer</option>
              <option value="Best meal">Best food</option>

            </select>


                </div>
                <br></br>
                <div className="form-group">
                    <input 
                        type="text" 
                        className="form-control col-4"
                        id="Ans"
                        value={secAns}
                        onChange={(e) => setAns(e.target.value)}
                        
                        placeholder="Enter the Answer "
                    />

                </div>

                <br></br>

                <div >
                    <button  className="btn btn-primary" onClick={saveVendor}>Register</button>
                </div>
            </form>
            <h5> </h5>
            <Link to="/loginvendor">Go for login</Link>
    </div>
 </div>
  );
}

export default RegisterVendor;
