

import React,{useEffect,useState} from 'react';
import axios from "axios";
import { useNavigate } from 'react-router';
import CartService from '../../Services/CartService';
import AllOrderService from '../../Services/AllOrderService';


const URL="http://localhost:8090/foodapp/cart";


function Cart(){

    const Navigate=useNavigate();

    const [cart,setCart] =useState([])
    const [price,setPrice]= useState(0);
    const [mob,setMob]=useState(localStorage.getItem("umob"));
    const[adr,setAdr]=useState(localStorage.getItem("uadr"));
    
    const init = () => {
      axios.get(URL).then(res  => {
        console.log(res)
        setCart(res.data)
   })
   .catch(err =>{
       console.log(err)

   })
    }
    useEffect(()=>{
        init();
    },[])
    const Logout= (e) => {
        e.preventDefault();
        Navigate('/userdash');
    }

    const removeDish=(crtid)=>{
      
        CartService.remove(crtid)
        .then(response => {
          console.log('Dish deleted successfully', response.data);
          init();
          })

          .catch(err =>{
            console.log(err)
     
        })

}


const finalOrder=()=>{
      
  info.map((citm)=>{
    const cid=citm.crtid
    const usnm=citm.uname
    const vnm=citm.vname
    const dshnm=citm.dname
    const dadr=adr
const order={uname:usnm,vname:vnm,dname:dshnm,dadress:dadr}


AllOrderService.create(order)
        .then(response => {
          console.log('Order Placed for', response.data);
         
          })

          .catch(err =>{
            console.log(err)
     
        })
    CartService.remove(cid)
        .then(response => {
          console.log('Order Placed for', response.data);
         
          })

          .catch(err =>{
            console.log(err)
     
        })

  })

  Navigate("/userdash")
  alert("Order Place Successfully and will be delievered to your Address in 45 Minutes.Now Explore more food.No item pending in cart now.")
         

}

const usn=localStorage.getItem("username")
const info=cart.filter((co)=>
co.uname.includes(usn));

useEffect(()=>{
    setPrice(info.reduce((acc,curr)=> acc +  Number(curr.ppu), 0));

},[cart])


/*
const handleChange = (item,d) => {
    const ind= cart.indexOf(item)
    const arr= cart;
    arr[ind].ppu +=d;

    if(arr[ind].ppu === 0) arr[ind].ppu = 1;
    setCart([...arr]);
    <button onClick={() => handleChange(item,1)}>+</button>
} */
/*const handlePrice = () =>{
    let amt=0;
    cart.map((dish)=> ( amt += dish.ppu * dish.price));
    setPrice(amt);

};
useEffect(()=>{
    handlePrice();

}) ;*/


const tohistory = () => {
    Navigate("/orderhis")
  }
    return(
        <div>
            <nav className='navbar navbar-lght bg-light'>
                <label className='navbar-brand'>My Food Cart</label>
                <button className='btn btn-primary' onClick={Logout}>Back to Dishes
                <span className='badge bg-secondary'></span></button> 

                <br></br>


                <button className='btn btn-primary' onClick={tohistory}>View Order History
                <span className='badge bg-secondary'></span></button> 
            </nav>
            <center>
                
            <h2>Happy Customer..</h2>

            
               <div className='container'>
                   <div className='row'>
                       {info.map((item)=>(
                           <div className='col-md-4'>
                               <div className='card'>
                               <img src={item.imgurl} className='card-img-top' width='200px' height='200px'/>
                               <div className='card-body'>
                               <h5 className='card-title'>{item.dname}</h5>
                                   <h5 className='card-title'>{item.vname}</h5>
                                   
                                   
                                   <div className='card-text'>Rs. {item.ppu}</div>
                                   
                                   <button className='btn btn-primary' onClick={()=> removeDish(item.crtid)}>Remove From Cart</button>
                       </div></div>
                       </div>)

                       )}
                   </div>
               </div> 
               
               <div className='spinner-border text-primary'>

               </div>
               <nav className='navbar navbar-lght bg-light'>
                <a className='navbar-brand'>Total amount-Rs {price}</a>
<br></br>

<h4>These are your Permanent Address and Contact Details.If you want to change Address for this delievery please change Here.</h4>

                <form>
                <div className="form-group">
                    <input 
                        type="text" 
                        className="form-control col-4"
                        id="adr"
                        value={adr}
                        onChange={(e) => setAdr(e.target.value)}

                        placeholder="Enter Address"
                    />

                </div>

                <br></br>

                <div className="form-group">
                    <input 
                        type="text" 
                        className="form-control col-3"
                        id="mob"

                        value={mob}
                        onChange={(e) => setMob(e.target.value)}
                        placeholder="Enter Mobile No."

                    />

                </div><br/>
  
            </form>
                <button className='btn btn-primary' onClick={finalOrder} >Proceed To Order 
                <span className='badge bg-secondary'></span></button> 
            </nav>
               
            </center>
        </div>
    )
}
export default Cart