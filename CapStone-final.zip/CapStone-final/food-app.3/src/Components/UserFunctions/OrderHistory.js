import { useEffect, useState } from 'react';
import { Link, useNavigate} from 'react-router-dom';

//import ReactConfirmAlert, { confirmAlert } from 'react-confirm-alert';
import 'react-confirm-alert/src/react-confirm-alert.css';
//import DishService from '../../Services/DishService';
import AllOrderService from '../../Services/AllOrderService'

const OrderList = () => {
  const Navigate=useNavigate();
  
  const [orders, setorders] = useState([]);

  const init = () => {
    AllOrderService.getAll()
      .then(response => {
        console.log('Printing orders data', response.data);
        
        setorders(response.data);
      })
      .catch(error => {
        console.log('Something went wrong', error);
      }) 
  }

 
  const vtof=localStorage.getItem("username")
  const info=orders.filter((nm)=>
  nm.uname.includes(vtof))
 

  useEffect(() => {
    init();
  }, []);

  const btl = () => {
    Navigate("/userdash")
  }


    

  return (
    <div className="container">
      
      <hr/>
      <div> 
<br>
</br>
<button className="btn btn-primary mb-2" onClick={btl}>Back to Home</button>
        <h2>My Dishes</h2>
        <table className="table table-bordered table-striped">
          <thead className="thead-dark">
            <tr>
              <th>User Name</th>
              <th>Dish Name</th>
              <th>Vendor Name</th>
              <th>Delievered to</th>
              
             
            </tr>
          </thead>
          <tbody>
          {
          info.map(order => (
              <tr key={order.oid}>
                <td>{order.uname}</td>
                <td>{order.dname}</td>
                <td>{order.vname}</td>
                <td>{order.dadress}</td>
             
              </tr>
            ))
          }
          </tbody>
        </table>
        
      </div>
    </div>
  );
}

export default OrderList;

