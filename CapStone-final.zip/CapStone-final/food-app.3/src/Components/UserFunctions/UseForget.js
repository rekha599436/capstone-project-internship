
import { render } from "@testing-library/react";
import { useState,useEffect} from "react";
import { Link, useNavigate, useParams } from "react-router-dom";

import UserService from "../../Services/UserService";


    

function UserForget() {
const Navigate=useNavigate();
   
const[usdata, setUsdata] = useState('');
    const[uname, setUname] = useState('');
    const[pass, setPass] = useState('');
    const [que,setque]=useState('');
    const [ans,setans]=useState('');



    const init = () => {
        UserService.getAll()
        .then(response => {
        console.log('Printing Uses data', response.data);
        setUsdata(response.data);
        })
        .catch(error => {
        console.log('Something went wrong', error);
        })
        }
        
        
        
        useEffect(() => {
        init();
        }, []);
    
    const CheckuserExist = (e) => {
        e.preventDefault();
        usdata.map((ud)=>{
            if (ud.uname==uname) {
               setque(ud.secQue)
            }
        })
        
      
    }

    const checkans = (e) => {
        e.preventDefault();
        usdata.map((ud)=>{
            if (ud.uname==uname && ud.secAns==ans) {
                alert("User Verified....Check Your Password in field and go back to home and login.")
              setPass(ud.pass)
            }
        })
        
      
    }
   

  return (
      
 <div>
    
    <br></br>
    <div className="container">
<h2>User...You Forgot your password?</h2>
<br></br>

    <form>
                <div className="form-group">
                    <input 
                        type="text" 
                        className="form-control col-4"
                        id="uname"
                        value={uname}
                        onChange={(e) => setUname(e.target.value)}

                        placeholder="Enter Username"
                    />

                </div>

                <br></br>

                <div >
                    <button  className="btn btn-primary" onClick={CheckuserExist} >Check my Username</button>
                </div>
                <br></br>

                <div className="form-group">
                    <input 
                        type="text" 
                        className="form-control col-4"
                        id="uname"
                        value={que}
                       

                        placeholder="Click on button Above.... if this box doesnot change you are entering wrong username"
                    />


<div className="form-group">
                    <input 
                        type="text" 
                        className="form-control col-4"
                        id="uname"
                        value={ans}
                        onChange={(e) => setans(e.target.value)}

                        placeholder="Enter Your Answer"
                    />

                </div>

                <br></br>


                </div>

                <br></br>
                <div >
                    <button  className="btn btn-primary" onClick={checkans} >Verify My Answer</button>
                </div>

                <div className="form-group">
                    <input 
                        type="text" 
                        className="form-control col-3"
                        id="pass"

                        value={pass}
                       
                        placeholder="Your Password will appear here please note it down"

                    />

                </div><br/>

                <div >
                <Link to="/loginuser"> Go for login</Link>
                </div>
            </form>
            <h5> </h5>
    </div>
 </div>
  );
}

export default UserForget;
