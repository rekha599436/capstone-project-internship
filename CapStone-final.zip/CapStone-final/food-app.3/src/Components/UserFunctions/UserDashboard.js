import React,{useEffect,useState} from 'react';
import axios from "axios";
import { useNavigate } from 'react-router';
import ReactConfirmAlert, { confirmAlert } from 'react-confirm-alert';
import 'react-confirm-alert/src/react-confirm-alert.css';
import CartService from '../../Services/CartService';
import {FaShoppingCart,FaSignOutAlt,FaPlusCircle} from 'react-icons/fa';
import { Badge } from 'react-bootstrap';



const API_URL="http://localhost:8090/foodapp/dishes";
const URL="http://localhost:8090/foodapp/cart";

function UserDashboard(){
    const [search,setSearch]=useState("")
    const un=localStorage.getItem("ufname")

    const Navigate=useNavigate();

    const [dishes,setDishes] =useState([])
    const [cart,setCart] =useState([])
    useEffect(()=>{
        axios.get(API_URL).then(res  => {
             console.log(res)
             setDishes(res.data)
        })
        .catch(err =>{
            console.log(err)

        })
    },[])


    const initcart = () => {
        axios.get(URL).then(res  => {
          console.log(res)
          setCart(res.data)
     })
     .catch(err =>{
         console.log(err)
  
     })
      }
      useEffect(()=>{
          initcart();
      },[])
    const LogoutHandle = (e) => {
        e.preventDefault();
        confirmAlert({
            title: 'Confirm Log-Out',
            message: 'Are you sure to Log Out.',
            buttons: [
              {
                label: 'Yes',
                onClick: () =>  {localStorage.removeItem("username")
                                localStorage.removeItem("ufname")
                            Navigate("/")}
              },
              {
                label: 'No',
                onClick: () => console.log('Not deleted')
              }
            ]
          });
        
      
    }

    const AddCart = (item) => {
        
        const fcart={uname:localStorage.getItem("username"),vname:item.vname,dname:item.dname,imgurl:item.imgurl,ppu:item.price}
        CartService.create(fcart)
            .then(response => {
                console.log("dish added successfully", response.data);
                
            })
            .catch(error => {
                console.log('something went wrong', error);
            })
      
    }

    const carthandle = () => {
        Navigate("/usercart")
        
      
    }

    const usn=localStorage.getItem("username")
const info=cart.filter((co)=>
co.uname.includes(usn));



    
    
   
    return(
        <div>
            <nav className='navbar navbar-lght bg-light'>
               

               
                
                
                
               
                <div>
                <button className='btn btn-primary' onClick={carthandle}><FaShoppingCart color="white" fontSize="25px"/> Cart
                <Badge>{info.length}</Badge><span className='badge bg-secondary'></span>

                </button>

                </div>
 <br></br>
                <button className='btn btn-primary' onClick={LogoutHandle}><FaSignOutAlt color="white" fontSize="25px"/>Log-out  
                <span className='badge bg-secondary'></span></button>
            </nav>

            <center>
            <form >
            <FaShoppingCart color="white" fontSize="25px"/><input width="100px" type="text" placeholder="Search Dish Name" value={search} onChange={(e)=>
                    setSearch(e.target.value)}/><br/><br/>   
                </form> 
            <h2>Welcome {un}....Explore the world of food Now!!</h2>

            
               <div className='container'>
                   <div className='row'>
                   {dishes.filter((dish)=>
                       dish.dname.toLowerCase().includes(search)).map((item)=>(
                           <div className='col-md-4'>
                               <div className='card'>
                               <img src={item.imgurl} className='card-img-top' width='200px' height='200px'/>
                               <div className='card-body'>
                                   <h5 className='card-title'>{item.dname}</h5>
                                   <h5 className='card-title'>{item.dtype}</h5>
                                   <h5 className='card-title'>{item.vname}</h5>
                                   <div className='card-text'>Rs. {item.price}</div>
                                   <button className='btn btn-primary' onClick={()=>AddCart(item)}>Add to Cart</button>
                       </div></div>
                       </div>)

                       )}
                   </div>
               </div> 
               
               <div className='spinner-border text-primary'>

               </div>
               
            </center>
        </div>
        
                    
                    
            
    )
            }
export default UserDashboard