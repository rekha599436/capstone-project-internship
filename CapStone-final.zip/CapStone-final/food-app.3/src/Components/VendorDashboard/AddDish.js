import { useState } from "react";
import { Link, useNavigate, useParams } from "react-router-dom";
import { useEffect } from "react";
import DishService from "../../Services/DishService";

const AddDish = () => {
    const v=localStorage.getItem("vendorname")
    const[dname, setName] = useState('');
    const[dtype,setType]=useState('Snack');
    const[vname,setVname]=useState(v);
    const[price,setPrice]=useState('');
    const[imgurl, seturl] = useState('');


    const Navigate = useNavigate();
    const {did}=useParams();
    console.log(did);

    const saveDish = (e) => {
        e.preventDefault();
        
        const dish = {dname,dtype,vname,price,imgurl,did};
       
        if (did) {
            //update
            DishService.update(dish)
                .then(response => {
                    console.log('dish data updated successfully', response.data);
                   Navigate("/vendordash");
                })
                .catch(error => {
                    console.log('Something went wrong', error);
                }) 
        } else {
            //create
            DishService.create(dish)
            .then(response => {
                console.log("dish added successfully", response.data);
                Navigate("/vendordash")
            })
            .catch(error => {
                console.log('something went wrong', error);
            })
        }
    }

    useEffect(() => {
        if (did) {
            DishService.get(did)
                .then(dish => {
                    setName(dish.data.dname);
                    setType(dish.data.dtype);
                    setVname(dish.data.vname);
                    setPrice(dish.data.price);
                    
                    seturl(dish.data.imgurl);
                })
                .catch(error => {
                    console.log('Something went wrong', error);
                })
        }
    }, [])
    return(
        <div className="container">
            <h3>Add Dishes</h3>
            <hr/>
            <form>
                <div className="form-group">
                    <input 
                        type="text" 
                        className="form-control col-4"
                        id="name"
                        value={dname}
                        onChange={(e) => setName(e.target.value)}
                        placeholder="Enter Dish name"
                    />

                </div>
                <br></br>
                <div className="form-group">
                    <input 
                        type="text" 
                        className="form-control col-4"
                        
                        value={vname}
                        
                        placeholder="Enter Vendor Name"
                    />

                </div>
                <br></br>
                <div className="form-group">
                    <input 
                        type="text" 
                        className="form-control col-4"
                        
                        value={price}
                        onChange={(e) => setPrice(e.target.value)}
                        placeholder="Enter Price"
                    />
                </div><br/>


                <div className="form-group">
                
                <label >Choose Dish Type :</label>
               
               <select name="Type"   value={dtype}
                        onChange={(e) => setType(e.target.value)}> 
               <option value="Snack">Snacks</option>
              <option value="Main Course">Main Course</option>
              <option value="Bevrages">Bevrages</option>
              <option value="Health Friendly">Health/Diet</option>

            </select>


                </div>
                <br></br>

                <div className="form-group">
                    <input 
                        type="text" 
                        className="form-control col-4"
                        id="url"
                        value={imgurl}
                        onChange={(e) => seturl(e.target.value)}
                        placeholder="Profile picture Link "
                    />

                </div><br/>


                <div >
                    <button onClick={(e) => saveDish(e)} className="btn btn-primary">Save</button>
                </div>
            </form>
            <hr/>
            <Link to="/vendordash">Back to List</Link>
        </div>
    )
}

export default AddDish;

