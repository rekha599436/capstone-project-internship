import { useEffect, useState } from 'react';
import { Link, useNavigate} from 'react-router-dom';

import ReactConfirmAlert, { confirmAlert } from 'react-confirm-alert';
import 'react-confirm-alert/src/react-confirm-alert.css';
import DishService from '../../Services/DishService';
import {FaSignOutAlt} from 'react-icons/fa';


const DishList = () => {
  const Navigate=useNavigate();
  
  const [dishes, setDishes] = useState([]);

  const init = () => {
    DishService.getAll()
      .then(response => {
        console.log('Printing Dishes data', response.data);
        
        setDishes(response.data);
      })
      .catch(error => {
        console.log('Something went wrong', error);
      }) 
  }

  const Logoutven = () => {
    confirmAlert({
      title: 'Confirm Log-Out',
      message: 'Are you sure to Log Out.',
      buttons: [
        {
          label: 'Yes',
          onClick: () =>  {localStorage.removeItem("vendorname")
          Navigate("/")}
                         
        },
        {
          label: 'No',
          onClick: () => console.log('Not deleted')
        }
      ]
    });
  }


  const vtof=localStorage.getItem("vendorname")
  const info=dishes.filter((nm)=>
  nm.vname.includes(vtof))
 

  useEffect(() => {
    init();
  }, []);

  const handleDelete = (did) => {
    console.log('Printing id', did);

   
    confirmAlert({
      title: 'Confirm to delete',
      message: 'Are you sure to do this.',
      buttons: [
        {
          label: 'Yes',
          onClick: () =>  DishService.remove(did)
          .then(response => {
            console.log('Dish deleted successfully', response.data);
            init();
          })
          .catch(error => {
            console.log('Something went wrong', error);
          })
        },
        {
          label: 'No',
          onClick: () => alert('Not deleted')
        }
      ]
    });



    /*employeeService.remove(id)
      .then(response => {
        console.log('employee deleted successfully', response.data);
        init();
      })
      .catch(error => {
        console.log('Something went wrong', error);
      })*/
  }

  return (
    <div className="container">
      <h3>Welcome {vtof}</h3>
      <hr/>
      <div>
        <Link to="/add" className="btn btn-primary mb-2">Add New Dish</Link>
<br>
</br>
<button className="btn btn-primary mb-2" onClick={Logoutven}><FaSignOutAlt color="white" fontSize="25px"/>Logout</button>
<h6>For Any Concerns Connect to Admin team in About Us Section</h6>
        <h2>My Dishes</h2>
        <table className="table table-bordered table-striped">
          <thead className="thead-dark">
            <tr>
              <th>Image</th>
              <th>Dish Name</th>
              <th>Dish Type</th>
              <th>Price</th>
              
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
          {
          info.map(dish => (
              <tr key={dish.did}>
                <td><img src={dish.imgurl } alt="profile-pic" width="100" 
     height="100"></img></td>
                <td>{dish.dname}</td>
                <td>{dish.dtype}</td>
                <td>{dish.price}</td>
                


                <td>
                  <Link className="btn btn-info" to={`/dish/edit/${dish.did}`}>Update</Link>
                  
                  <button className="btn btn-danger ml-2" onClick={() => {
                    handleDelete(dish.did);
                  }}>Delete</button>
                </td>
              </tr>
            ))
          }
          </tbody>
        </table>
        
      </div>
    </div>
  );
}

export default DishList;

