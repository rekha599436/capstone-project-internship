
import { render } from "@testing-library/react";
import { useState,useEffect} from "react";
import { Link, useNavigate, useParams } from "react-router-dom";

import VendorServices from "../../Services/VendorServices";
  

function VendorForget() {
const Navigate=useNavigate();
   
const[vndata, setVndata] = useState('');
    const[uname, setUname] = useState('');
    const[pass, setPass] = useState('');
    const [que,setque]=useState('');
    const [ans,setans]=useState('');



    const init = () => {
        VendorServices.getAll()
        .then(response => {
        console.log('Printing Vendors data', response.data);
        setVndata(response.data);
        })
        .catch(error => {
        console.log('Something went wrong', error);
        })
        }
        
        
        
        useEffect(() => {
        init();
        }, []);
    
    const CheckuserExist = (e) => {
        e.preventDefault();
        vndata.map((ud)=>{
            if (ud.vuname==uname) {
               setque(ud.secQue)
            }
        })
        
      
    }

    const checkans = (e) => {
        e.preventDefault();
        vndata.map((ud)=>{
            if (ud.vuname==uname && ud.secAns==ans) {
                alert("Vendor Verified....Check Your Password in field and go back to home and login.")
              setPass(ud.pass)
            }
        })
        
      
    }
   
   

   



  return (
      
 <div>
    
    <br></br>
    <div className="container">
<h2>Vendor...You Foget your Password</h2>
<br></br>

    <form>
                <div className="form-group">
                    <input 
                        type="text" 
                        className="form-control col-4"
                        id="uname"
                        value={uname}
                        onChange={(e) => setUname(e.target.value)}

                        placeholder="Enter Username"
                    />

                </div>

                <br></br>

                <div >
                    <button  className="btn btn-primary" onClick={CheckuserExist} >Check My Username</button>
                </div>
                <br></br>

                <div className="form-group">
                    <input 
                        type="text" 
                        className="form-control col-4"
                        id="uname"
                        value={que}
                       

                        placeholder="Click on button Above.... if this box doesnot change you are entering wrong username"
                    />


<div className="form-group">
                    <input 
                        type="text" 
                        className="form-control col-4"
                        id="uname"
                        value={ans}
                        onChange={(e) => setans(e.target.value)}

                        placeholder="Enter Your Answer"
                    />

                </div>

                <br></br>


                </div>

                <br></br>
                <div >
                    <button  className="btn btn-primary" onClick={checkans} >Verify My Answer</button>
                </div>

                <div className="form-group">
                    <input 
                        type="text" 
                        className="form-control col-3"
                        id="pass"

                        value={pass}
                       
                        placeholder="Your Password will appear here please note it down"

                    />

                </div>

                <br></br>

                <div >
                <Link to="/loginvendor"> Go for login</Link>
                </div>
            </form>
            <h5> </h5>
    </div>
 </div>
  );
}

export default VendorForget;
