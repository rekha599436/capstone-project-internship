import {NavLink,Link} from "react-router-dom"
import './Styles/Navbar.css'

function NavPre() {
    return (
   <div className="main">
     <div  className="logo">
       Welcome To Foody

     </div>
     <nav className="item">
       <ul className="ul">
         <li>
           <Link to='/about'>About Us</Link>

         </li>
         <li>
           <Link to='/loginuser'>User Login</Link>

         </li>
         <li>
           <Link to='/loginvendor'>Vendor Login</Link>

         </li>
         <li>
           <Link to='/loginadmin'>Admin Login</Link>

         </li>

       </ul>

     </nav>
      { /*<nav class="navbar navbar-expand-lg navbar-light bg-light">
  <div class="container-fluid">
    <a class="navbar-brand"><NavLink to="/" exact={+true}>Food App</NavLink></a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNavDropdown">
      <ul class="navbar-nav">
        <li class="nav-item">
          <a class="nav-link active" aria-current="page">About Us</a>
        </li>
        
        <li className="nav-item dropdown">
          <a className="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" role="button" data-bs-toggle="dropdown" aria-expanded="false">
            Login
          </a>
          <ul class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
            <li><a className="dropdown-item" ><NavLink to="/loginuser" >User</NavLink></a></li>
            <li><a className="dropdown-item" ><NavLink to="/loginvendor" >Vendor</NavLink></a></li>
            <li><a className="dropdown-item" ><NavLink to="/loginadmin" >Admin</NavLink></a></li>
          </ul>
        </li>


        <li className="nav-item dropdown">
          <a className="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink2" role="button" data-bs-toggle="dropdown" aria-expanded="false">
            Register
          </a>
          <ul class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
            <li><a className="dropdown-item" ><NavLink to="/registeruser" >User</NavLink></a></li>
            <li><a className="dropdown-item"><NavLink to="/registervendor" >Vendor</NavLink></a></li>
            
          </ul>
        </li>


        <li className="nav-item dropdown">
          <a className="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink2" role="button" data-bs-toggle="dropdown" aria-expanded="false">
            Forgot Password
          </a>
          <ul class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
            <li><a className="dropdown-item" ><NavLink to="/userforget">User</NavLink></a></li>
            <li><a className="dropdown-item"><NavLink to="/vendorforget" >Vendor</NavLink></a></li>
            
          </ul>
        </li>
      </ul>
    </div>
  </div>
</nav>
    */}


   </div>
    );
  }
  
  export default NavPre;
  