import {BrowserRouter,Route,Routes} from "react-router-dom"
import MainPage from "./MainPage"
import NavPre from "./prelognav"
import LoginAdmin from "./Registration/AdminLogin"
import LoginUser from "./Registration/UserLogin"
import RegisterUser from "./Registration/UserRegister"
import LoginVendor from "./Registration/VendorLogin"
import RegisterVendor from "./Registration/VendorRegister"
import DishList from "./VendorDashboard/DishList"
import AddDish from "./VendorDashboard/AddDish"
import UserDashboard from "./UserFunctions/UserDashboard"
import Cart from "./UserFunctions/FoodCart"
import AddVendors from "./Admin Dashboard/UpdateVendor"
import AdminsList from "./Admin Dashboard/AdminWatchList"
import UserForget from "./UserFunctions/UseForget"
import VendorForget from "./VendorDashboard/VendorForget"
import OrderList from "./UserFunctions/OrderHistory"



function Routers(){
    return(
        
            <BrowserRouter>
            <NavPre/>
             
           <Routes>
               
            
            <Route path='/' component={MainPage} exact={+true}/>
            
            <Route path='/registeruser' element={<RegisterUser/>}></Route>
            <Route path='/registervendor' element={<RegisterVendor/>}></Route> 
            <Route path='/loginvendor' element={<LoginVendor/>}></Route>
            <Route path='/loginuser' element={<LoginUser/>}></Route>
            <Route path='/loginadmin' element={<LoginAdmin/>}></Route> 
            <Route path='/vendordash' element={<DishList/>}></Route> 
             
            <Route path="/dish/edit/:did" element={<AddDish/>}></Route> 
            <Route path='/add' element={<AddDish/>}></Route>
            <Route path='/userdash' element={<UserDashboard/>}></Route>
            <Route path='/usercart' element={<Cart/>}></Route>
            <Route path='/admindash' element={<AdminsList/>}></Route>
            <Route path='/vendor/edit/:vid' element={<AddVendors/>}></Route>
            <Route path='/userforget' element={<UserForget/>}></Route>
            <Route path='/vendorforget' element={<VendorForget/>}></Route>
            <Route path='/orderhis' element={<OrderList/>}></Route>
            
           
            
            
            </Routes>
            
            
            
            </BrowserRouter>
        )
    
}
export default Routers