import httpClient from "../http-common";

const getAll = () => {
    return httpClient.get('/admins');
}

const create = data => {
    return httpClient.post("/admins", data);
}

const get = id => {
    return httpClient.get(`/admins/${id}`);
}

const update = data => {
    return httpClient.put('/admins', data);
}

const remove = id => {
    return httpClient.delete(`/admins/${id}`);
}
export default { getAll, create, get, update, remove };