import httpClient from "../http-common";

const getAll = () => {
    return httpClient.get('/cart');
}

const create = data => {
    return httpClient.post("/carts", data);
}

const get = id => {
    return httpClient.get(`/cart/${id}`);
}

const update = data => {
    return httpClient.put('/carts', data);
}

const remove = id => {
    return httpClient.delete(`/carts/${id}`);
}
export default { getAll, create, get, update, remove };