import httpClient from "../http-common";

const getAll = () => {
    return httpClient.get('/dishes');
}

const create = data => {
    return httpClient.post("/dishes", data);
}

const get = did => {
    return httpClient.get(`/dishes/${did}`);
}

const update = data => {
    return httpClient.put('/dishes', data);
}

const remove = did => {
    return httpClient.delete(`/dishes/${did}`);
}
export default { getAll, create, get, update, remove };